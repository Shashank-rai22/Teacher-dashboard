// $(document).ready(function() {
//     $('.navbar-toggler').click(function() {
//         $('.collapsible-nav').toggle();
//         // $('.navbar-nav .ml-auto').toggle();
//     });
// });

function handleButtonClick(button) {
    if (button === 'button2') {
        document.querySelector('.button2').classList.add('selected');
        document.querySelector('.button1').classList.remove('selected');
    } else {
        document.querySelector('.button1').classList.add('selected');
        document.querySelector('.button2').classList.remove('selected');
    }
}

document.addEventListener("DOMContentLoaded", function() {
    const buttons = document.querySelectorAll('.nav-btn');
    buttons.forEach(btn => {
        btn.addEventListener('click', function () {
            buttons.forEach(btn => btn.classList.remove('selected'));
            this.classList.add('selected');
        });
    });
});